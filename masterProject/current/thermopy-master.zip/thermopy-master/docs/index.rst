.. thermopy documentation master file, created by
   sphinx-quickstart on Mon Jul 18 17:15:22 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to thermopy's documentation!
====================================

Contents:

.. toctree::
   :maxdepth: 2

   thermopy


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

